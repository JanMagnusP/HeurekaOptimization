#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
require(tidyverse)
require(magrittr)
require(wesanderson)
require(knitr)
require(tidyr)
require(ggpubr)
require(gridExtra)
require(EnvStats)
require(stringi)

`%nin%` = Negate(`%in%`)

# Load data ---------------------------------------------------------------

t1<-read.csv("P:/ShinyApps/HeurekaOptimization/t1.csv")
t1$Stand <- factor(t1$Stand)

t1 <- t1 %>%
    group_by(Stand, Plot, ScenarioLevel) %>%
    filter(Period <= Period[Åtgärd== "FinalFelling"])

stand_fac <- c("1",   "2",   "3",   "4",   "5",   "6",   "10",  "11",  "17",  "18",  "19",  "51",  "52",  "53",  "54","55",  "201", "202", "203", "204")

# Define UI for miles per gallon app ----
ui <- pageWithSidebar(
    
    # App title ----
    headerPanel("Miles Per Gallon"),
    
    # Sidebar panel for inputs ----
    sidebarPanel(
            
        selectInput(inputId = "Stand",
                        label = "Select Stand",
                        choices = stand_fac,
                        selected = "4", )
        
    ),
        
    # Main panel for displaying outputs ----
    mainPanel(
        plotOutput("plot"))
)


# Define server logic to plot various variables against mpg ----
server <- function(input, output) {
    output$plot <- renderPlot({
        ggplot(aes(y = GY, x = Year, group = Plot), data = t1[t1$Stand == input$Stand,]) +
            geom_point(width= 0.2, aes(color=Harvest), size = 2)+ 
            
            geom_line(aes(linetype = "dotted"), size = 0.7)+
            
            ggtitle("Basal area") +
            scale_y_continuous(name = expression("Basal area " ~ (m^{2}~m^{-2})), 
                               breaks = seq(0, 70, 5), limits = c(0, 70))+ 
            scale_x_continuous(name = expression("Year"),
                               breaks = seq(0, 70, 5))+
            theme_bw()+
            theme(legend.position = "right")+ 
            scale_linetype_manual(values=c(2,1)) +
            facet_wrap(~ScenarioLevel, ncol = 3)
    })
}



# Run the application 
shinyApp(ui = ui, server = server)





